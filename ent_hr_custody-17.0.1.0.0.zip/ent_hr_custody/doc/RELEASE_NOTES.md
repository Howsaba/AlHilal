## Module ent_hr_custody

#### 19.02.2024
#### Version 17.0.1.0.0
##### ADD
- Initial commit for Enterprise Open HRMS Custody